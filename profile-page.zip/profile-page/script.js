function changeName(element) {
    document.querySelector(element).innerText = "Rick Roll"
}

function remove(element) {
    document.querySelector(element).remove()
}