function removeAlert(element) {
    document.getElementById('notice').remove()
}