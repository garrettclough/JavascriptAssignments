function counter(element) {
    document.querySelector(element).innerText++
}